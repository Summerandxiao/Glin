var userInfo;
summerready = function() {
	if (summer.getStorage('userInfo_local')) {//有数据
		userInfo = JSON.parse(summer.getStorage('userInfo_local'));
		$("#userId").attr("value", userInfo.userId);
		$("#userName").attr("value", userInfo.userName);
		$("#userMobile").attr("value", userInfo.userMobile);
		$("#appVersion").attr("value", "版本 " + userInfo.appVersion);
	}

	//待办
	$("#upComing").on("click", function(e) {
		summer.openWin({
			id : 'upComing',
			url : 'html/upComing.html',
			reload : true
		});
		summer.closeWin({
			id : 'MyInfo',
			url : 'html/MyInfo.html'
		});
	});
	//应用
	$("#index").on("click", function(e) {
		summer.openWin({
			id : 'index',
			url : 'index.html',
			reload : true
		});
		summer.closeWin({
			id : 'MyInfo',
			url : 'html/MyInfo.html'
		});
	});

};

function updatePass() {
	var uid = userInfo.uid;
	var password = userInfo.userPass;
	console.log(uid + ":" + password);
	summer.setStorage("uid", uid);
	summer.setStorage("password", password);
	summer.openWin({
		id : 'updatePwd',
		url : 'html/updatePwd.html',
		pageParam : {
			uid : 'uid',
			password : 'password'
		}
	});
};

function exit() {
	UM.confirm({
		title : '友情提示：',
		text : '您确定要退出系统吗？',
		btnText : ["取消", "确定"],
		overlay : true,
		ok : function() {
			localStorage.removeItem("userInfo_local");
//			summer.openWin({
//				id : 'login',
//				url : 'html/login.html',
//				reload : true
//			});
          summer.exitApp();
			summer.closeWin({
				id : 'MyInfo',
				url : 'html/MyInfo.html'
			});
		},
		cancle : function() {
		}
	});
};