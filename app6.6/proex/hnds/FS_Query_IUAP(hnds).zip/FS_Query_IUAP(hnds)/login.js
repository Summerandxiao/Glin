﻿var ip = 'sccwapp.ha-l-tax.gov.cn:6102';//生产
//var ip = 'ysccwapp.ha-l-tax.gov.cn:6095';//预生产
//var ip='192.168.1.123:8080';
var userCode;
var versionInfo = eval("(" + summer.getAppVersion() + ")");
var appVersion = versionInfo.versionName;
summerready = function() {
//	用户名
    userCode=summer.pageParam.swrydm;
	summer.setStorage("ip", ip);
	document.addEventListener("backbutton", onBackKeyDown, false);
    	//监听返回键
    updateAppCheck();
//    userLogin();

}
var userLogin = function() {
	UM.showLoadingBar({
		text : "正在加载",
		icons : 'ti-reload',
	});
    UM.hideLoadingBar();
	var paramStr = "uid=" + encodeURIComponent(encodeURIComponent(userCode));
	paramStr += "&CLIENT=MOBILE";
	//var url = 'https://' + ip + '/FS';
	/*$.ajax(url, {
		data : "",
		dataType : 'jsonp',
		crossDomain : true,
		timeout : 3000, //超时时间，毫秒
		complete : function(data) {
			if (data.status == 200) {
				//	alert("服务可用");*/
				$.ajax({
					type : "GET",
					async : false,
					dataType : "jsonp",
					jsonp : "jsonpCallback",
					error : function(data) {
						alert('login' + JSON.stringify(data));
					},
					url : "https://" + ip + "/FS/loginServlet?" + paramStr,
					success : function(data) {
						if (data.resultCode == "1") {
							$('#errorInfo').html('');
							var userData = data.rows;
							var userInfo_local = {
								uid : userData.ID,
								userId : userData.USER_CODE,
								userName : userData.USER_NAME,
								coCode : userData.CO_CODE,
								coName : userData.CO_NAME,
								orgCode : userData.ORG_CODE,
								orgName : userData.ORG_NAME,
								nd : userData.ND,
								userMobile : userData.USER_MOBILE,
								roleId:userData.roleId,
								userType : userData.USER_TYPE,
								ip : ip,
								appVersion: appVersion
							};
							summer.setStorage("userInfo_local", JSON.stringify(userInfo_local));
							summer.setStorage("islogout", true);
							summer.setStorage("userId", userCode);
							summer.setStorage("nd", userData.ND);
							UM.hideLoadingBar();
							summer.openWin({
								id : 'index',
								url : 'index.html',
								pageParam : {
									username : 'sa',
									passwrod : '1212'
								}
							});

						} else {
							alert(data.rows);
							UM.hideLoadingBar();
						}
					}
				});

			/*} else if (data.statusText == "timeout" && data.status == 0) {
				UM.hideLoadingBar();
				alert("服务不可用,请联系管理员");
			} else if (data.status == 404) {
			    alert("data.status1111111:"+data.status);
				UM.hideLoadingBar();
				UM.toast({
					title : '提示：',
					text : '找不到可用的服务,请联系管理员',
					duration : 2000
				});
			} else {
			    alert("data.status22222222222:"+data.status);
				UM.hideLoadingBar();
				UM.toast({
					title : '提示：',
					text : '找不到可用的服务,请联系管理员',
					duration : 2000
				});
			}
		}
	});*/
}
function onBackKeyDown() {
	if (confirm("再点击一次退出!")) {
		summer.exitApp()
	};
	document.removeEventListener("backbutton", onBackKeyDown, false);
	//注销返回键
	var intervalID = setInterval(function() {
		clearInterval(intervalID);
		document.addEventListener("backbutton", onBackKeyDown, false);
		// 监听返回键
	}, 3000);
};

/**
 * APP版本更新检查
 */
function updateAppCheck() {
	$.ajax({
		type : "POST",
		async : false,
		dataType : "json",
		url : "https://" + ip + "/FS/services/appVersionService/getAppVersionInfo?",
		success : function(data) {
			if (data.resultCode == "1") {
				var versionData = data.rows;
				var serverVersionInfo = versionData[0];
				// 如果当前应用版本和服务器最新版本不一致 则提示是否更新应用
				var versionInfo = eval("(" + summer.getAppVersion() + ")");
//		        alert("手机版本：" + versionInfo.versionName + "\n" + "服务器版本：" + serverVersionInfo.VERSION_CODE);
				//var isOK = parseInt(versionData[0].APP_VERSION) > parseInt(versionInfo.versionName);
				if (serverVersionInfo.VERSION_CODE > versionInfo.versionName) {
					UM.confirm({
						title : '软件版本更新',
						text : '检测到新版本'+serverVersionInfo.VERSION_CODE+'，立即更新？',
						btnText : ["下次再说", "立即更新"],
						overlay : true,
						ok : function() {
							updateMobileApproval(serverVersionInfo);
						},
						cancle : function() {
							 userCode=summer.pageParam.swrydm;
                             summer.setStorage("ip", ip);
                             document.addEventListener("backbutton", onBackKeyDown, false);
							 userLogin();
							 return;
						}
					});
				} else {
//					alert("无需升级啦");
					userCode=summer.pageParam.swrydm;
                    summer.setStorage("ip", ip);
                    document.addEventListener("backbutton", onBackKeyDown, false);
                    if (userCode) {
                    	  userLogin();
                      }
				}
			}
		}
	});
}

/**
 * 根据手机系统类型更新android应用
 */
function updateMobileApproval(versionData) {
	var os = summer.getSysInfo();
	if (os.systemType == "android") {
//	    var androidUrl = "https://ysczcyyzx.ha-l-tax.gov.cn:6015/shareStoreDir/yyzx/UFGOVFS/downloads/android-debug.apk";//预生产环境地址
		var androidUrl = "https://yyzx.ha-l-tax.gov.cn/shareStoreDir/yyzx/cwglapp/downloads/android-debug.apk";//生产环境地址
		summer.upgradeApp({
			url : androidUrl
		}, function(ret) {
//			alert("下载更新成功");
		}, function(ret) {
//			alert("下载更新失败");
             UM.toast({
     					title : '提示：',
     					text : '下载更新失败',
     					duration : 3000
     				});
		});
	}
}