﻿var bdata;
var userInfo;
var ip;
summerready = function() {
	UM.showLoadingBar({
		"text" : "加载中",
		"icons" : "ti-loading"
	});
	var ip = summer.getStorage('ip');
	var url = 'https://' + ip + '/FS';
	userInfo = JSON.parse(summer.getStorage('userInfo_local'));
	var curStatus = summer.pageParam.curStatus;
	//var curStatus = 1;
	if (curStatus == 0) {
		$("#callback").hide();
		$("#approve").show();
		$("#retreat").show();
	} else if (curStatus == 1) {
		$("#approve").hide();
		$("#retreat").hide();
		$("#callback").show();
	}
	if (userInfo) {//有数据
		bdata = summer.getStorage("bdata");
		var billId = bdata["BILL_ID"];
		//	var instanceId = bdata["INSTANCE_ID"];
		//	var nd = userInfo.nd;
		//	var userId = userInfo.userId;
		//	var coCode = userInfo.coCode;
		//	var uid = userInfo.uid;

		loadData(billId);
		loadArProcess(billId);
		UM.hideLoadingBar();

	} else {//无数据
		summer.openWin({
			id : 'login',
			url : 'html/login.html',
			pageParam : {
				compoId : '',
				title : '登录'
			}
		});
	}

	$("#approve").on("click", function(e) {
		var opi_content = $("#app_content").val();
		if (opi_content == undefined || opi_content == "") {
//			alert("请填写审批意见");
             UM.toast({
     					title : '提示：',
     					text : '请填写审批意见',
     					duration : 3000
     				});
			return;
		}
		var approveUrl = 'https://' + ip + '/FS' + "/services/billService/commitAndPush";
		var param = "BILL_ID=" + billId + "&APPROVALOPINION=" + opi_content + "&ND=" + userInfo.nd + "&USERID=" + userInfo.userId + "&CO_CODE=" + userInfo.coCode + "&UID=" + userInfo.uid + "&CLIENT=MOBILE";
		var approveUrl = approveUrl + "?" + param;
		$.ajax({
			type : "POST",
			async : false,
			url : approveUrl,
			success : function(data) {
				if (data.resultCode == "1") {
//					alert("审批通过");
                   UM.toast({
     					title : '提示：',
     					text : '审批通过',
     					duration : 3000
     				});
					summer.openWin({
						id : "upComing",
						url : "html/upComing.html",
						reload : true
					});
					summer.closeWin({
						id : 'arAuditDetail',
						url : 'html/arAuditDetail.html'
					});
				} else {
//					alert('操作失败,请核实!');
                       UM.toast({
     					title : '提示：',
     					text : '操作失败,请核实!',
     					duration : 3000
     				});
				}
			}
		});
	});

	$("#retreat").on("click", function(e) {//退回上一岗
		var opi_content = $("#app_content").val()
		if (opi_content == undefined || opi_content == "") {
//			alert("请填写审批意见");
                UM.toast({
     					title : '提示：',
     					text : '请填写审批意见',
     					duration : 3000
     				});
			return;
		}
		$.getJSON('https://' + ip + '/FS' + "/services/billService/untread?BILL_ID=" + billId + "&APPROVALOPINION=" + opi_content + "&CO_CODE=" + userInfo.coCode + "&USERID=" + userInfo.userId + "&UID=" + userInfo.uid + "&CLIENT=MOBILE",
		function(data) {
			if (data.resultCode == "1") {
//				alert("退回成功");
                 UM.toast({
     					title : '提示：',
     					text : '退回成功',
     					duration : 3000
     				});
				summer.openWin({
					id : "upComing",
					url : "html/upComing.html",
					reload : true
				});
				summer.closeWin({
					id : 'arAuditDetail',
					url : 'html/arAuditDetail.html'
				});
			} else {
//				alert('退回上一岗失败,请核实!');
                   UM.toast({
     					title : '提示：',
     					text : '退回上一岗失败,请核实!',
     					duration : 3000
     				});
			}
		});
	});
	$("#callback").on("click", function() {
		$.getJSON("https://" + ip + "/FS/services/billService/callBack?BILL_ID=" + billId + "&CO_CODE=" + userInfo.coCode + "&USERID=" + userInfo.userId + "&UID=" + userInfo.uid + "&CLIENT=MOBILE",
		function(data) {
			if (data.resultCode == "1") {
//				alert("收回成功");
                  UM.toast({
     					title : '提示：',
     					text : '收回成功',
     					duration : 3000
     				});
				summer.openWin({
					id : "upComing",
					url : "html/upComing.html",
					reload : true
				});
				summer.closeWin({
					id : 'arAuditDetail',
					url : 'html/arAuditDetail.html'
				});
			} else {
//				alert('收回失败,请核实!');
                UM.toast({
     					title : '提示：',
     					text : '收回失败,请核实!',
     					duration : 3000
     				});
			}
		});
	});
	$("#attachFile").on("click", function() {
		UM.showLoadingBar({
			text : "加载中",
			icons : 'ti-loading',
		});
		summer.openWin({
			id : 'attachFile',
			url : 'html/attachFile.html',
			pageParam : {
				billId : billId
			}
		});
	});
}
function loadData(billId) {
	var userInfo = JSON.parse(summer.getStorage('userInfo_local'));
	var urlParam = "BILL_ID=" + billId;
	urlParam += "&UID=" + userInfo.uid;
	urlParam += "&CLIENT=MOBILE";
	/**
	 * 加载基本信息和费用项信息
	 */
	$.ajax({
		type : "POST",
		async : false,
		url : "https://" + userInfo.ip + "/FS/services/billService/selectByBillIdMobile?" + urlParam,
		success : function(data) {
			var billDeData;
			var billDeDataNew = [];
			//如果有外币显示外币，没有外币显示本币--start-----------------
			if (JSON.stringify(data.rows.bill_expense_foreign) != "{}" && data.rows.bill_expense_foreign != undefined) {
				billDeData = data.rows.bill_expense_foreign;
				//组装最后结果
				for (var i in billDeData) {
					billDeDataNew.push({
						"EXPENSE_NAME" : i.split("&", 1),
						"MONEY" : util.changeTwoDecimal(billDeData[i].currencyMoney) + billDeData[i].currencyKind
					});
				}
			} else {
				billDeData = data.rows.bill_expense;
				//组装最后结果
				for (var i in billDeData) {
					billDeDataNew.push({
						"EXPENSE_NAME" : i,
						"MONEY" : util.changeTwoDecimal(billDeData[i]) + "元"
					});
				}
			}
			//如果有外币显示外币，没有外币显示本币--end---------------

			$("#inputDate").text(bdata["INPUT_DATE_TOSTRING"]);
			$("#reason").text(bdata["REASON"]);
			$("#checkMoney").text(util.changeTwoDecimal(bdata["CHECK_MONEY"]));
			$("#statusName").text(bdata["BILL_STATUS_NAME"]);
		     if(bdata["BILL_STATUS_NAME"]=='未提交'){
                 $("#retreat").hide();
                }
             if(bdata["BILL_STATUS_NAME"]=='已完成'){
                 $("#callback").hide();
                 }
			var listgroupText = doT.template($("#listgroup-tmpl").text());
			$("#umListGroupRow").html(listgroupText(billDeDataNew));
		},
		error : function(data) {
			alert(data.statusText);
		}
	});
	/**
	 * 加载预算信息
	 */
	/*$.ajax({
		type : "POST",
		async : false,
		url : "https://" + userInfo.ip + "/FS/services/billService/selectBgByBillIdMobile?" + urlParam,
		success : function(data) {
			console.log(data.rows);
			if (data.resultCode == 1) {
				for (var j = 0; j < data.rows.length; j++) {
					var billDeData = data.rows[j];
					var billDeDataNew = [];
					//组装最后结果
					for (var i in billDeData) {
						billDeDataNew.push({
							"GL_INFO_NAME" : i,
							"GL_INFO_VALUE" : billDeData[i]
						});
					}
					var listgroupText = doT.template($("#glinfo-tmpl").text());
					$("#glinfoRow").append(listgroupText(billDeDataNew));
				}
			}
		}
	});*/
}

/**
 * 加载报销系统实时查询的流程跟踪，移动审批用
 */
function loadArProcess(billId) {
	var userInfo = JSON.parse(summer.getStorage('userInfo_local'));
	var urlParam = "BILL_ID=" + billId;
	urlParam += "&CO_CODE=" + userInfo.coCode;
	urlParam += "&UID=" + userInfo.uid;
	urlParam += "&CLIENT=MOBILE";
	$.ajax({
		type : "POST",
		async : false,
		url : "https://" + userInfo.ip + "/FS/services/billService/selectTraceInfo?" + urlParam,
		success : function(data) {
			var traceInfo = data.rows;
			for (var p in traceInfo) {
				var description = traceInfo[p].description;
				if (description != undefined && description.indexOf('流向') > -1) {
					traceInfo[p].description = '通过';
				} else if (description == undefined) {
					traceInfo[p].description = '待处理';
				}
				var executeTime = traceInfo[p].executeTime;
				if (executeTime == undefined || executeTime.length == 0) {
					traceInfo[p].executeTime = "";
				}
			}
			var ViewModel = function() {
			};
			var viewModel = new ViewModel();
			viewModel.data = ko.observableArray(traceInfo);
			ko.applyBindings(viewModel);
			console.log(traceInfo);
		}
	});
}
