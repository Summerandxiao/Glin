﻿var nd,sdata,coCode,userInfo;
//coCode='141016602001';
summerready = function() {
	var ip = summer.getStorage('ip');
	var url = 'https://' + ip + '/FS';
	userInfo=JSON.parse(summer.getStorage('userInfo_local'));
	if (userInfo) {//有数据
		sdata = summer.getStorage("sdata");
		nd = sdata["YEAR"];
		coCode=userInfo.coCode;
		loadData();//从FS加载数据
	} else {//无数据
		summer.openWin({
			id : 'login',
			url : 'html/login.html',
			pageParam : {
				compoId : '',
				title : '登录'
			}
		});
	}
}

function loadData(){
	var userInfo = JSON.parse(summer.getStorage('userInfo_local'));
	var act;
	var pay;
	var temp1 = 0;
	var temp2 = 0;
	var payMoney = 0;
	var actMoney = 0;
	var salaryType = "";
	var urlParam="ND="+ nd;
	urlParam+="&IS_DISPLAY=Y";
	urlParam+="&CO_CODE="+coCode;
	urlParam+="&PRTYPE_CODE="+summer.getStorage("prsType");
		
	$.ajax({
		type : "POST",
		async : false,
		url : "https://" + userInfo.ip + "/FS/services/salaryService/selectSalaryDetailType?"+urlParam,
		success : function(data) {
			var salaryDeData = data.rows;
			for (var i in salaryDeData) {
				var prItemCode = salaryDeData[i].PRITEM_CODE;
				if (prItemCode&&prItemCode.indexOf('PR_PAYLIST_N') != -1) {
					salaryDeData[i].PRITEM_CALC_TYPE = changeTwoDecimal(sdata[prItemCode]);
				} else {
					salaryDeData[i].PRITEM_CALC_TYPE = sdata[prItemCode];
				}
			}
			
			var salaryDeDataNew=[];//组装最后结果
			
			for (var i in salaryDeData) {
				var prItemCode = salaryDeData[i].PRITEM_CODE;
				if (prItemCode&&prItemCode.indexOf('PR_PAYLIST_N') != -1) {
					salaryDeData[i].PRITEM_CALC_TYPE = changeTwoDecimal(sdata[prItemCode]) + '元';
				} else {
					salaryDeData[i].PRITEM_CALC_TYPE = sdata[prItemCode];
				}
				//金额为0的不显示
				if(prItemCode&&sdata[prItemCode]!=0){
					salaryDeDataNew.push(salaryDeData[i]);
				}
			}
			$("#name").text(sdata["EMP_NAME"]);
			$("#month").text(sdata["YEAR"]+"年-"+sdata["MO"]+"月");
			$("#prs_level").text(sdata["PRS_LEVEL"]);
			$("#prs_type").text(sdata["PRS_TYPE"]);
			
			var listgroupText = doT.template($("#listgroup-tmpl").text());
			$("#umListGroupRow").html(listgroupText(salaryDeDataNew));  
		}
	});
}


function changeTwoDecimal(money) {
	if (isNaN(money)) {
		return money;
	}
	var f_x = parseFloat(money);

	var f_x = Math.round(money * 100) / 100;
	var s_x = f_x.toString();
	var pos_decimal = s_x.indexOf('.');
	if (pos_decimal < 0) {
		pos_decimal = s_x.length;
		s_x += '.';
	}
	while (s_x.length <= pos_decimal + 2) {
		s_x += '0';
	}
	return s_x;
} 